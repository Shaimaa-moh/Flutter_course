package com.example.shopping_app_shaimaa

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
