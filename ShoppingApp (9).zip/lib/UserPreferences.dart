import 'package:shoppingapp/Model/UserProfile.dart';

class UserPreferences {
  static const myUser = UserProfile(
    imagePath:
        'https://th.bing.com/th/id/R.cba12e52b61d3450571e02658321dc32?rik=5i0VkYQQ2Bh3gw&pid=ImgRaw&r=0',
    userName: 'Shaimaa Mohamed',
    email: 'shimomoh693@gmail.com',
    phone: '01002030944',
    about:
        'Computer and Software Engineer ,obsessed by fashion and member in GDC ',
  );
}
